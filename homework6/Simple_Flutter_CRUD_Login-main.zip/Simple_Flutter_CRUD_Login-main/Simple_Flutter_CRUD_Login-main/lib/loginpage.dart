import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_crud/homepage.dart';
import 'package:http/http.dart' as http;

Future<String> loginUser(String email, String password) async {
  final response = await http.post(
    Uri.parse('http://192.168.0.104/flutterapi/crudflutter/login.php'),
    body: {
      'email': email,
      'password': password,
    },
  );

  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
    return data["success"] == true ? "Success" : "Error";
  }
  return "Error";
}
