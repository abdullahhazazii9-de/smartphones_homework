import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_crud/tambahdata.dart';
import 'package:flutter_crud/editdata.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List _listdata = [];

  Future _getdata() async {
    try {
      final response = await http.get(
        Uri.parse("http://192.168.0.104/flutterapi/crudflutter/getdata.php"),
      );

      if (response.statusCode == 200) {
        setState(() {
          _listdata = jsonDecode(response.body);
        });
      }
    } catch (e) {
      print(e);
    }
  }

  Future<bool> _deletedata(String id) async {
    try {
      final response = await http.post(
        Uri.parse("http://192.168.0.104/flutterapi/crudflutter/delete.php"),
        body: {"id": id},
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        return data["success"] == true;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  @override
  void initState() {
    super.initState();
    _getdata();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      body: ListView.builder(
        itemCount: _listdata.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(_listdata[index]['nama']),
              subtitle: Text(_listdata[index]['alamat']),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditDataPage(
                      ListData: _listdata[index],
                    ),
                  ),
                );
              },
              trailing: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        content: Text(
                            "Yakin ingin menghapus data ${_listdata[index]['nama']}?"),
                        actions: [
                          TextButton(
                            onPressed: () {
                              _deletedata(_listdata[index]['id'])
                                  .then((value) {
                                if (value) {
                                  Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const HomePage()),
                                    (route) => false,
                                  );
                                }
                              });
                            },
                            child: const Text("Ya"),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text("Tidak"),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const TambahData()),
          );
        },
      ),
    );
  }
}
